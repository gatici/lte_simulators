# EnodeB Charm

This is a native charm used by Open Source Mano (OSM) to add day-2 primitive to an enodeB + radio emulator, written in the [Python Operator Framwork](https://github.com/canonical/operator)
